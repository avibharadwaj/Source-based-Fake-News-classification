// $(function(){
//   $('#name').keyup(function(){
//     $('#greet').text('Hello '+ $('#name').val());
//   })
// })

chrome.tabs.query({'active': true, 'windowId': chrome.windows.WINDOW_ID_CURRENT},
   function(tabs){
      // $('#greet').text('Hello '+ $('#name').val());
       $('#greet').text(tabs[0].url);
   }
 
);

